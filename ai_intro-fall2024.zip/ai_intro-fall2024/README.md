# Репозиторий курса "Введение в ИИ"
[Google таблица с вашими успехами](https://docs.google.com/spreadsheets/d/1k2MYXEp_OVQrink_XRC1PwoM0ZuNMeNz4VTWY7cI3hE/edit?usp=sharing)
